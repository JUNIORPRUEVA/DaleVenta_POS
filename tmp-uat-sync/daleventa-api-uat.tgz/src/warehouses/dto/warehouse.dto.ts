import { IsOptional, IsString, IsUUID, MaxLength } from "class-validator";

export class CreateWarehouseDto {
  @IsString()
  @MaxLength(120)
  name!: string;

  @IsString()
  @MaxLength(32)
  code!: string;
}

export class UpdateWarehouseDto {
  @IsOptional()
  @IsString()
  @MaxLength(120)
  name?: string;

  @IsOptional()
  @IsString()
  @MaxLength(32)
  code?: string;
}

export class UpdateTerminalWarehouseDto {
  @IsUUID()
  warehouseId!: string;
}
