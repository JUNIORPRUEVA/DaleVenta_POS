import {
  BadRequestException,
  ConflictException,
  Injectable,
  NotFoundException,
} from "@nestjs/common";
import { Prisma, ProductSource } from "@prisma/client";
import { requireTenant, type TenantUser } from "../auth/tenant-context";
import { PrismaService } from "../prisma/prisma.service";
import { ProductSourceResolver } from "../products/product-source.resolver";
import {
  CreateWarehouseDto,
  UpdateTerminalWarehouseDto,
  UpdateWarehouseDto,
} from "./dto/warehouse.dto";

type Tx = Prisma.TransactionClient;

@Injectable()
export class WarehousesService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly productSourceResolver: ProductSourceResolver,
  ) {}

  async list(user: TenantUser) {
    const companyId = requireTenant(user);
    const rows = await this.prisma.warehouse.findMany({
      where: { companyId },
      orderBy: [{ isDefault: "desc" }, { isActive: "desc" }, { name: "asc" }],
      include: {
        _count: {
          select: {
            defaultTerminals: { where: { isActive: true } },
            stocks: true,
          },
        },
      },
    });
    return rows.map((row) => ({
      id: row.id,
      name: row.name,
      code: row.code,
      isDefault: row.isDefault,
      isActive: row.isActive,
      terminalCount: row._count.defaultTerminals,
      stockRowCount: row._count.stocks,
      createdAt: row.createdAt,
      updatedAt: row.updatedAt,
      deactivatedAt: row.deactivatedAt,
    }));
  }

  async listTerminals(user: TenantUser) {
    const companyId = requireTenant(user);
    const rows = await this.prisma.terminal.findMany({
      where: { companyId },
      orderBy: [{ isDefault: "desc" }, { isActive: "desc" }, { name: "asc" }],
      include: {
        defaultWarehouse: {
          select: { id: true, name: true, code: true, isActive: true },
        },
      },
    });
    return rows.map((row) => ({
      id: row.id,
      name: row.name,
      code: row.code,
      isDefault: row.isDefault,
      isActive: row.isActive,
      defaultWarehouseId: row.defaultWarehouseId,
      defaultWarehouse: row.defaultWarehouse,
      deviceBound: (row.deviceFingerprint ?? "").trim().length > 0,
    }));
  }

  async create(user: TenantUser, dto: CreateWarehouseDto) {
    const companyId = requireTenant(user);
    const name = this.cleanName(dto.name);
    const code = this.cleanCode(dto.code);
    return this.prisma.warehouse.create({
      data: {
        companyId,
        name,
        code,
        isActive: true,
        isDefault: false,
      },
    });
  }

  async update(user: TenantUser, id: string, dto: UpdateWarehouseDto) {
    const companyId = requireTenant(user);
    const data: Prisma.WarehouseUpdateInput = {};
    if (dto.name !== undefined) data.name = this.cleanName(dto.name);
    if (dto.code !== undefined) data.code = this.cleanCode(dto.code);
    if (Object.keys(data).length === 0) {
      throw new BadRequestException("No hay cambios para guardar.");
    }
    await this.ensureWarehouse(companyId, id);
    try {
      return await this.prisma.warehouse.update({
        where: { id },
        data,
      });
    } catch (error) {
      if (this.isUniqueConstraint(error)) {
        throw new ConflictException(
          "Ya existe un almacen con ese codigo en esta empresa.",
        );
      }
      throw error;
    }
  }

  async setDefault(user: TenantUser, id: string) {
    const companyId = requireTenant(user);
    return this.prisma.$transaction(async (tx) => {
      const warehouse = await this.ensureWarehouse(companyId, id, tx);
      if (!warehouse.isActive) {
        throw new BadRequestException(
          "Solo un almacen activo puede ser predeterminado.",
        );
      }
      await tx.warehouse.updateMany({
        where: { companyId, isDefault: true, id: { not: id } },
        data: { isDefault: false },
      });
      await tx.warehouse.update({
        where: { id },
        data: { isDefault: true },
      });
      return this.ensureWarehouse(companyId, id, tx);
    });
  }

  async activate(user: TenantUser, id: string) {
    const companyId = requireTenant(user);
    await this.ensureWarehouse(companyId, id);
    return this.prisma.warehouse.update({
      where: { id },
      data: { isActive: true, deactivatedAt: null, deactivatedById: null },
    });
  }

  async deactivate(user: TenantUser, id: string) {
    const companyId = requireTenant(user);
    return this.prisma.$transaction(async (tx) => {
      const warehouse = await this.ensureWarehouse(companyId, id, tx);
      if (warehouse.isDefault) {
        throw new BadRequestException(
          "No se puede desactivar el almacen predeterminado.",
        );
      }
      const nonZero = await tx.warehouseStock.count({
        where: {
          companyId,
          warehouseId: id,
          quantity: { not: new Prisma.Decimal(0) },
        },
      });
      if (nonZero > 0) {
        throw new ConflictException(
          "No se puede desactivar un almacen con stock distinto de cero.",
        );
      }
      const linkedTerminals = await tx.terminal.count({
        where: { companyId, defaultWarehouseId: id, isActive: true },
      });
      if (linkedTerminals > 0) {
        throw new ConflictException(
          "Reasigna las terminales activas antes de desactivar este almacen.",
        );
      }
      return tx.warehouse.update({
        where: { id },
        data: {
          isActive: false,
          deactivatedAt: new Date(),
          deactivatedById: user.id ?? null,
        },
      });
    });
  }

  async updateTerminalWarehouse(
    user: TenantUser,
    terminalId: string,
    dto: UpdateTerminalWarehouseDto,
  ) {
    const companyId = requireTenant(user);
    return this.prisma.$transaction(async (tx) => {
      const terminal = await tx.terminal.findFirst({
        where: { id: terminalId, companyId },
      });
      if (!terminal) throw new NotFoundException("Terminal no encontrada.");
      await this.ensureActiveWarehouse(companyId, dto.warehouseId, tx);
      return tx.terminal.update({
        where: { id: terminalId },
        data: { defaultWarehouseId: dto.warehouseId },
        include: {
          defaultWarehouse: {
            select: { id: true, name: true, code: true, isActive: true },
          },
        },
      });
    });
  }

  async productStockBreakdown(user: TenantUser, productId: string) {
    const companyId = requireTenant(user);
    const source =
      await this.productSourceResolver.resolveForCompany(companyId);
    if (source.source !== ProductSource.LOCAL) {
      return {
        productId,
        source: source.source,
        readOnly: true,
        total: null,
        reconciled: true,
        warehouses: [],
        message:
          "La disponibilidad por almacen solo esta disponible para productos LOCAL.",
      };
    }

    const product = await this.prisma.product.findFirst({
      where: { id: productId, companyId },
      select: { id: true, stock: true },
    });
    if (!product) throw new NotFoundException("Producto no encontrado.");

    const warehouses = await this.prisma.warehouse.findMany({
      where: { companyId },
      orderBy: [{ isDefault: "desc" }, { isActive: "desc" }, { name: "asc" }],
      include: {
        stocks: {
          where: { productId },
          select: { quantity: true },
          take: 1,
        },
      },
    });
    const rows = warehouses.map((warehouse) => {
      const quantity = warehouse.stocks[0]?.quantity ?? new Prisma.Decimal(0);
      return {
        warehouseId: warehouse.id,
        warehouseName: warehouse.name,
        warehouseCode: warehouse.code,
        isDefault: warehouse.isDefault,
        isActive: warehouse.isActive,
        quantity: Number(quantity),
        quantityDecimal: quantity.toString(),
      };
    });
    const total = rows.reduce(
      (sum, row) => sum.plus(row.quantityDecimal),
      new Prisma.Decimal(0),
    );
    return {
      productId: product.id,
      source: source.source,
      readOnly: false,
      total: Number(product.stock ?? 0),
      totalDecimal: product.stock?.toString?.() ?? "0",
      warehouseTotal: Number(total),
      warehouseTotalDecimal: total.toString(),
      reconciled: total.equals(product.stock ?? 0),
      warehouses: rows,
    };
  }

  private async ensureWarehouse(
    companyId: string,
    id: string,
    tx: Tx | PrismaService = this.prisma,
  ) {
    const warehouse = await tx.warehouse.findFirst({
      where: { id, companyId },
    });
    if (!warehouse) throw new NotFoundException("Almacen no encontrado.");
    return warehouse;
  }

  private async ensureActiveWarehouse(companyId: string, id: string, tx: Tx) {
    const warehouse = await tx.warehouse.findFirst({
      where: { id, companyId, isActive: true },
    });
    if (!warehouse) {
      throw new BadRequestException("Almacen activo no encontrado.");
    }
    return warehouse;
  }

  private cleanName(value: string) {
    const clean = value.trim().replace(/\s+/g, " ");
    if (!clean) throw new BadRequestException("El nombre es obligatorio.");
    return clean;
  }

  private cleanCode(value: string) {
    const clean = value.trim().replace(/\s+/g, "-").toUpperCase();
    if (!clean) throw new BadRequestException("El codigo es obligatorio.");
    return clean;
  }

  private isUniqueConstraint(error: unknown) {
    return (
      error instanceof Prisma.PrismaClientKnownRequestError &&
      error.code === "P2002"
    );
  }
}
